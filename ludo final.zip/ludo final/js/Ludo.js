
const playerPiecesElements = {
    'P1': document.querySelectorAll('[player-id="P1"].player-piece'),
    'P2': document.querySelectorAll('[player-id="P2"].player-piece'),
    'P3': document.querySelectorAll('[player-id="P3"].player-piece'),
    'P4': document.querySelectorAll('[player-id="P4"].player-piece'),
}

PLAYERS = JSON.parse(localStorage.getItem('activePlayers'))
STATE = JSON.parse(localStorage.getItem('STATE'))
BASE_POSITIONS = JSON.parse(localStorage.getItem('BASE_POSITIONS'))
SAFE_POSITIONS = JSON.parse(localStorage.getItem('SAFE_POSITIONS'))
HOME_POSITIONS = JSON.parse(localStorage.getItem('HOME_POSITIONS'))
TURNING_POINTS = JSON.parse(localStorage.getItem('TURNING_POINTS'))
HOME_ENTRANCES = JSON.parse(localStorage.getItem('HOME_ENTRANCES'))
START_POSITIONS = JSON.parse(localStorage.getItem('START_POSITIONS'))

const initCurrentPositions = (PLAYERS) => {
    currentPositions = {}
    PLAYERS.forEach(player => {
        currentPositions[player] = []
    })

    return currentPositions
}

class Ludo {
    currentPositions = {}

    _diceValue
    get diceValue() {
        return this._diceValue
    }
    set diceValue(value) {
        this._diceValue = value

        UI.setDiceValue(value)
    }

    _turn
    get turn() {
        return this._turn
    }
    set turn(value) {
        this._turn = value
        UI.setTurn(value)
    }

    _state
    get state() {
        return this._state
    }
    set state(value) {
        this._state = value

        if(value === STATE.DICE_NOT_ROLLED) {
            UI.enableDice()
            UI.unhighlightPieces()
        } else {
            UI.disableDice()
        }
    }

    constructor() {
        console.log("loading...")
        this.currentPositions = initCurrentPositions(PLAYERS)
        console.log(this.currentPositions)

        this.resetGame()
        
        // this.diceValue = 4
        // this.turn = 3
        // this.state = STATE.DICE_NOT_ROLLED

        this.listenDiceClick()
        this.listenResetClick()
        this.listenPieceClick()

        // this.setPiecePosition('P1', 0, HOME_ENTRANCES.P1[4])
        // this.setPiecePosition('P1', 1, HOME_POSITIONS.P1)
        // this.setPiecePosition('P1', 2, HOME_POSITIONS.P1)
        // this.setPiecePosition('P1', 3, HOME_POSITIONS.P1)
        this.setPiecePosition('P1', 0, 0)
        this.setPiecePosition('P2', 0, 1)
    }

    listenDiceClick() {
        UI.listenDiceClick(this.onDiceClick.bind(this))
    }
    onDiceClick() {
        console.log('dice clicked!')
        this.diceValue = 1 //+ Math.floor(Math.random() * 6)
        this.state = STATE.DICE_ROLLED
        
        this.checkForEligiblePieces()
    }
    checkForEligiblePieces() {
        // console.log(this.turn)
        const player = PLAYERS[this.turn]
        // console.log(player)
        const eligiblePieces = this.getEligiblePieces(player)
        // console.log(eligiblePieces)
        if(eligiblePieces.length) {
            UI.highlightPieces(playerPiecesElements, player, eligiblePieces)
        } else {
            this.incrementTurn()
        }
    }
    getEligiblePieces(player) {
        return [0, 1, 2, 3].filter(piece => {
            const currentPosition = this.currentPositions[player][piece]

            if(currentPosition === HOME_POSITIONS[player]) {
                return false
            }

            if(BASE_POSITIONS[player].includes(currentPosition) && this.diceValue !== 6) {
                return false
            }
            if(HOME_ENTRANCES[player].includes(currentPosition) && this.diceValue > HOME_POSITIONS[player] - currentPosition) {
                return false
            }

            return true
        })
    }
    incrementTurn() {
        this.turn = (this.turn + 1) % PLAYERS.length
        // console.log(this.turn)
        this.state = STATE.DICE_NOT_ROLLED
    }

    listenResetClick() {
        UI.listenResetClick(this.resetGame.bind(this))
    }
    resetGame() {
        console.log('reset game')
        this.currentPositions = structuredClone(BASE_POSITIONS)

        PLAYERS.forEach(player => {
            [0, 1, 2, 3].forEach(piece => {
                this.setPiecePosition(player, piece, this.currentPositions[player][piece])
            })
        })

        this.turn = 0
        this.state = STATE.DICE_NOT_ROLLED
    }

    listenPieceClick() {
        UI.listenPieceClick(this.onPieceClick.bind(this))
    }
    onPieceClick(event) {
        const target = event.target
        if(!target.classList.contains('player-piece') /* || !target.classList.contains('highlight') */) {
            return
        }
        
        console.log('piece clicked')
        const player = target.getAttribute('player-id')
        const piece = target.getAttribute('piece')
        console.log(player, piece)
        this.handlePieceClick(player, piece)
    }
    handlePieceClick(player, piece) {
        console.log(player, piece)
        const currentPosition = this.currentPositions[player][piece]
        
        if(BASE_POSITIONS[player].includes(currentPosition)) {
            this.setPiecePosition(player, piece, START_POSITIONS[player])
            this.state = STATE.DICE_NOT_ROLLED
            return
        }

        UI.unhighlightPieces()
        this.movePiece(player, piece, this.diceValue)
    }
    setPiecePosition(player, piece, newPosition) {
        this.currentPositions[player][piece] = newPosition
        UI.setPiecePosition(playerPiecesElements, player, piece, newPosition)
    }
    movePiece(player, piece, moveBy) {
        const interval = setInterval(() => {
            this.incrementPiecePosition(player, piece)
            moveBy--

            if(moveBy === 0) {
                clearInterval(interval)

                if(this.hasPlayerWon(player)) {
                    alert(`Player: ${player} has won!`)
                    this.resetGame()
                    return
                }

                const isKill = this.checkForKill(player, piece)

                if(isKill || this.diceValue === 6) {
                    this.state = STATE.DICE_NOT_ROLLED
                    return
                }

                this.incrementTurn()
            }
        }, 300)
    }
    checkForKill(player, piece) {
        const currentPosition = this.currentPositions[player][piece];
        let kill = false;

        [0, 1, 2, 3].forEach(piece => {

            if(this.givePosition(player, piece, currentPosition) && !SAFE_POSITIONS.includes(currentPosition)) {
                this.setPiecePosition(opponent, piece, BASE_POSITIONS[opponent][piece]);
                kill = true
            }
        });

        return kill
    }
    givePosition(player, piece, currentPosition) {
        const opponents = ['P1', 'P2', 'P3', 'P4']
        const temp = opponents.filter(item => item !== player)
        temp.forEach(opponent => {
            const opponentPosition = this.currentPositions[opponent][piece];

            if(currentPosition === opponentPosition) return true
        })

        return false
    }
    hasPlayerWon(player) {
        return [0, 1, 2, 3].every(piece => this.currentPositions[player][piece] === HOME_POSITIONS[player])
    }
    incrementPiecePosition(player, piece) {
        this.setPiecePosition(player, piece, this.getIncrementedPosition(player, piece))
    }
    getIncrementedPosition(player, piece) {
        const currentPosition = this.currentPositions[player][piece]

        if(currentPosition === TURNING_POINTS[player]) {
            return HOME_ENTRANCE[player][0]
        }
        else if(currentPosition === 51) {
            return 0
        }
        return currentPosition + 1
    }
}

window.addEventListener('load', () => {
    ludo = new Ludo()


    // UI.setPiecePosition(playerPiecesElements, 'P1', 0, 0)
    // UI.setPiecePosition(playerPiecesElements, 'P2', 0, 13)
    // UI.setPiecePosition(playerPiecesElements, 'P3', 0, 26)
    // UI.setPiecePosition(playerPiecesElements, 'P4', 0, 39)
    
    // UI.setTurn(0)
    // UI.setTurn(1)
    // UI.setTurn(2)
    // UI.setTurn(3)

    // UI.disableDice()
    // UI.enableDice()

    // UI.highlightPieces(playerPiecesElements, 'P1', [0])
    // UI.highlightPieces(playerPiecesElements, 'P2', [0])
    // UI.highlightPieces(playerPiecesElements, 'P3', [0])
    // UI.highlightPieces(playerPiecesElements, 'P4', [0])

    // UI.unhighlightPieces(playerPiecesElements, 'P1', [0])
    // UI.unhighlightPieces(playerPiecesElements, 'P2', [0])
    // UI.unhighlightPieces(playerPiecesElements, 'P3', [0])
    // UI.unhighlightPieces(playerPiecesElements, 'P4', [0])

    // UI.setDiceValue(6)
})