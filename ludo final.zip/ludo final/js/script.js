
let players = {
    'P1' : 0,
    'P2' : 0,
    'P3' : 0,
    'P4' : 0
}

document.getElementById('player1').addEventListener('click', () => {
    if(players['P1']) {
        document.getElementById('player1').classList.remove('highlight')
        players['P1'] = 0
    }else {
        document.getElementById('player1').classList.add('highlight')
        players['P1'] = 1
    }
    console.log(players['P1'])
})
document.getElementById('player2').addEventListener('click', () => {
    if(players['P2']) {
        document.getElementById('player2').classList.remove('highlight')
        players['P2'] = 0
    }else {
        document.getElementById('player2').classList.add('highlight')
        players['P2'] = 1
    }
    console.log(players['P2'])
})
document.getElementById('player3').addEventListener('click', () => {
    if(players['P3']) {
        document.getElementById('player3').classList.remove('highlight')
        players['P3'] = 0
    }else {
        document.getElementById('player3').classList.add('highlight')
        players['P3'] = 1
    }
    console.log(players['P3'])
})
document.getElementById('player4').addEventListener('click', () => {
    if(players['P4']) {
        document.getElementById('player4').classList.remove('highlight')
        players['P4'] = 0
    }else {
        document.getElementById('player4').classList.add('highlight')
        players['P4'] = 1
    }
    console.log(players['P4'])
})

const validateGame = () => {
    temp = []
    Object.keys(players).forEach(player => {
        if(players[player]) temp.push(player)
    })

    return temp
}
const play = () => {
    if(validateGame().length > 1) {
        document.querySelector('.modal-container').style.visibility = "hidden"
        // document.getElementById('game').innerHTML = '<iframe src="ludo.html" style="max-width: 900px; max-height: 600px; border: none;"></iframe>'
        window.location.assign('./ludo.html')
        localStorage.setItem('activePlayers', JSON.stringify(validateGame()))
    }
    else alert("selectionner au mois deux joueurs")

    console.log(validateGame())
}