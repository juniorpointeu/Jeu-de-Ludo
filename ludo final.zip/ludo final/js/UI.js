
COORDINATES_MAP = JSON.parse(localStorage.getItem('COORDINATES_MAP'))
STEP_LENGTH = localStorage.getItem('STEP_LENGTH')
PLAYERS = JSON.parse(localStorage.getItem('activePlayers'))

class UI {
    static listenDiceClick(callback) {
        document.querySelector('#dice-btn').addEventListener('click', callback)
    }

    static listenResetClick(callback) {
        document.querySelector('button#reset-btn').addEventListener('click', callback)
    }

    static listenPieceClick(callback) {
        document.querySelector('.player-pieces').addEventListener('click', callback)
    }

    /**
     * 
     * @param {object} playerPiecesElements
     * @param {string} player 
     * @param {Number} piece 
     * @param {Number} newPosition 
     */

    static setPiecePosition(playerPiecesElements, player, piece, newPosition) {
        if(!playerPiecesElements[player] || !playerPiecesElements[player][piece]) {
            console.error(`Player element of given player: ${player} and piece: ${piece} not found`)
            return
        }

        const [x, y] = COORDINATES_MAP[newPosition]

        const pieceElement = playerPiecesElements[player][piece]
        pieceElement.style.top = y * STEP_LENGTH + '%'
        pieceElement.style.left = x * STEP_LENGTH + '%'
    }

    static setTurn(index) {
        if(index < 0 || index >= PLAYERS.length) {
            console.error('index out of bound!')
            return
        }
        
        const player = PLAYERS[index]

        // Display player ID
        document.querySelector('.active-player span').innerText = player

        const activePlayerBase = document.querySelector('.player-base.highlight')
        if(activePlayerBase) {
            activePlayerBase.classList.remove('highlight')
        }
        // highlight
        document.querySelector(`[player-id="${player}"].player-base`).classList.add('highlight')
    }

    static enableDice() {
        document.querySelector('#dice-btn').removeAttribute('disabled')
    }

    static disableDice() {
        document.querySelector('#dice-btn').setAttribute('disabled', '')
    }

    /**
     * 
     * @param {object} playerPiecesElements
     * @param {string} player 
     * @param {Number[]} pieces 
     */
    static highlightPieces(playerPiecesElements, player, pieces) {
        pieces.forEach(piece => {
            const pieceElement = playerPiecesElements[player][piece]
            pieceElement.classList.add('highlight')
        })
    }

    static unhighlightPieces() {
        document.querySelectorAll('.player-piece.highlight').forEach(ele => {
            ele.classList.remove('highlight')
        })
    }

    static setDiceValue(value) {
        document.querySelector('.dice-value').innerText = value
    }
}